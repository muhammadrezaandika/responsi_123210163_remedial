import 'package:flutter/material.dart';
import 'package:url_launcher/url_launcher.dart';
import '../models/maps.dart';

class MapDetailScreen extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    final GameMap gameMap = ModalRoute.of(context)!.settings.arguments as GameMap;

    return Scaffold(
      appBar: AppBar(
        title: Text(gameMap.displayName),
      ),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Container(
              padding: EdgeInsets.all(8.0),
              decoration: BoxDecoration(
                color: Colors.red, // Warna merah
                borderRadius: BorderRadius.circular(8.0),
              ),
              child: Icon(
                Icons.map, // Ikona peta
                size: 64.0,
                color: Colors.white,
              ),
            ),
            SizedBox(height: 16.0),
            Text(
              gameMap.displayName,
              style: TextStyle(fontSize: 24, fontWeight: FontWeight.bold, color: Colors.red), // Warna merah
            ),
            SizedBox(height: 8),
            Image.network(gameMap.splash),
            SizedBox(height: 16),
            ElevatedButton(
              onPressed: () async {
                final url = 'https://valorant-api.com/v1/maps/${gameMap.uuid}';
                if (await canLaunch(url)) {
                  await launch(url);
                } else {
                  throw 'Could not launch $url';
                }
              },
              child: Row(
                mainAxisSize: MainAxisSize.min,
                children: [
                  Icon(Icons.open_in_browser, color: Colors.white), // Ikona browser
                  SizedBox(width: 8),
                  Text('View in Browser', style: TextStyle(color: Colors.white)), // Teks tombol
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}
