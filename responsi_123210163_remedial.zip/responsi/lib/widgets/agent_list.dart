import 'package:flutter/material.dart';
import '../models/agent.dart';

class AgentList extends StatelessWidget {
  final List<Agent> agents;

  AgentList({required this.agents});

  @override
  Widget build(BuildContext context) {
    return ListView.builder(
      itemCount: agents.length,
      itemBuilder: (context, index) {
        final agent = agents[index];
        return ListTile(
          leading: Image.network(agent.displayIcon),
          title: Text(agent.displayName),
          subtitle: Text(agent.description),
          onTap: () {
            Navigator.pushNamed(
              context,
              '/agentDetail',
              arguments: agent,
            );
          },
        );
      },
    );
  }
}
